
<?php
//Linking the configuration file
require 'config.php';
if(isset($_POST["search"])){
    $input= $_POST["input"];
    if($input=='Engineer'){
   
    if(!empty($input)){
        $query="SELECT * FROM `jobseekereng` WHERE `JS_category` = 'Engineer'";
        $result = $con->query($query);
        if($result->num_rows > 0){
            //read data
            echo '<div class="recruitrounded">';
            echo ' <div class="container2">';
            while($row = $result->fetch_assoc()){
                //Read and utilize the row data
                echo '<div class="box3">';
                echo ' <img src="data:image/jfif;base64,'.base64_encode($row['JS_image'] ).'" class="img-thumbnail" />';
                echo '<div class="rsastext">';
                echo " <BR/> " ."My Name:"." <BR/> ". $row["JS_name"] . "<BR />". "<BR />".'My ID:' . $row["JS_ID"] . "<BR />". "<BR />"
                ."Contact me:". "<BR />". $row["JS_contact"]. "<BR />" . $row["JS_email"] . "<BR/>" ;
                echo '</div>';
                echo '</div>';
                }
            echo '</div>';
            echo '</div>';
            }
        }
    
    }

elseif($input=='Accountant'){

    if(!empty($input)){
   
        $query="SELECT * FROM `jobseekeracct` WHERE `JSA_category` = 'Accountant'";
        $result = $con->query($query);
        if($result->num_rows > 0){
            //read data
            echo '<div class="recruitrounded">';
            echo ' <div class="container2">';
            while($row = $result->fetch_assoc()){
                //Read and utilize the row data
                echo '<div class="box3">';
                echo ' <img src="data:image/jfif;base64,'.base64_encode($row['JSA_image'] ).'" class="img-thumbnail" />';
                echo '<div class="rsastext">';
                echo " <BR/> " ."My Name:"." <BR/> ". $row["JSA_name"] . "<BR />". "<BR />".'My ID:' . $row["JSA_ID"] . "<BR />". "<BR />"
                ."Contact me:". "<BR />". $row["JSA_contact"]. "<BR />" . $row["JSA_email"] . "<BR/>" ;
                echo '</div>';
                echo '</div>';
                }
            echo '</div>';
            echo '</div>';
            }
        }
}

elseif($input=='Receptionist'){

    
    if(!empty($input)){
   
        $query="SELECT * FROM `jobseekerrecep` WHERE `JSR_category` = 'Receptionist'";
        $result = $con->query($query);
        if($result->num_rows > 0){
            //read data
            echo '<div class="recruitrounded">';
            echo ' <div class="container2">';
            while($row = $result->fetch_assoc()){
                //Read and utilize the row data
                echo '<div class="box3">';
                echo ' <img src="data:image/jfif;base64,'.base64_encode($row['JSR_image'] ).'" class="img-thumbnail" />';
                echo '<div class="rsastext">';
                echo " <BR/> " ."My Name:"." <BR/> ". $row["JSR_name"] . "<BR />". "<BR />".'My ID:' . $row["JSR_ID"] . "<BR />". "<BR />"
                ."Contact me:". "<BR />". $row["JSR_contact"]. "<BR />" . $row["JSR_email"] . "<BR/>" ;
                echo '</div>';
                echo '</div>';
                }
            echo '</div>';
            echo '</div>';
            }
        }
}


elseif($input=='Secretary'){

    
    if(!empty($input)){
   
        $query="SELECT * FROM `jobseekerrecep` WHERE `JSR_category` = 'Secretary'";
        $result = $con->query($query);
        if($result->num_rows > 0){
            //read data
            echo '<div class="recruitrounded">';
            echo ' <div class="container2">';
            while($row = $result->fetch_assoc()){
                //Read and utilize the row data
                echo '<div class="box3">';
                echo ' <img src="data:image/jfif;base64,'.base64_encode($row['JSR_image'] ).'" class="img-thumbnail" />';
                echo '<div class="rsastext">';
                echo " <BR/> " ."My Name:"." <BR/> ". $row["JSR_name"] . "<BR />". "<BR />".'My ID:' . $row["JSR_ID"] . "<BR />". "<BR />"
                ."Contact me:". "<BR />". $row["JSR_contact"]. "<BR />" . $row["JSR_email"] . "<BR/>" ;
                echo '</div>';
                echo '</div>';
                }
            echo '</div>';
            echo '</div>';
            }
        }
}

}

    $con->close();

?>

<!DOCTYPE html>
<html>
<head>
<title>
    SEARCH BAR
</title>
<link rel="stylesheet" href="style1.css">
</head>
<body>

<form method="post"  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<input type="text" name="input" class="search_input" placeholder="Search">
<input type="submit" name="search" class="abtbtn" value="searchh">
</form>
<br>
<br>
<br>

</body>
</html>