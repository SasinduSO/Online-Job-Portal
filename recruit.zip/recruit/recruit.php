
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RECRUIT</title>
    <link rel="stylesheet" href="style1.css">

    </head>
<body>
    <header>
    
    <div class="top">
        <img src="recruit images/f1076210572373e91c9187e3d971ecc3.jpg" class="logo" >
        <h1>𝒥𝑜𝒷 𝒟𝒾𝒸𝑒𝓈</h1>
        
        <button type ="button" id="btn1"> Sign in</button>
        <button type ="button" id="btn2"> Profile</button>
        <a href="test11.php">
      <input type="search" class="search_input" placeholder="Search.."/>
     </a>

        </div>
        <div class="nav1">
         <ul>
             <li><a href="#">Home</a></li>
             <li><a href="#">Find Jobs</a></li>
             <li><a href="#">Recruit</a></li>
             <li><a href="#">Comapnies</a></li>
             <li><a href="#">News</a></li>
             <li><a href="#">About</a></li>
             <li><a href="#">Contact Us</a></li>
         </ul>
        </div>
    </header>
    <div class= "hero_image">
    <br>
    <br>
    <br>
    <center>
    <div class="recruitrounded">
        <div class="TopRounded">
            <div class="sastexthead">
          Engineers
            </div>
        </div>
        <br>
        <br>
       <div class="container2">
         <?php
//Linking the configuration file
require 'config.php';
$sql = "select * from jobseekerENG";
$result = $con->query($sql);
if($result->num_rows > 0){
//read data
while($row = $result->fetch_assoc()){
//Read and utilize the row data
echo '<div class="box3">';
echo ' <img src="data:image/jfif;base64,'.base64_encode($row['JS_image'] ).'" class="img-thumbnail" />';
echo '<div class="rsastext">';
echo " <BR/> " ."My Name:"." <BR/> ". $row["JS_name"] . "<BR />". "<BR />".'My ID:' . $row["JS_ID"] . "<BR />". "<BR />"
."Contact me:". "<BR />". $row["JS_contact"]. "<BR />" . $row["JS_email"] . "<BR/>" ;
echo '</div>';
echo '</div>';
}
}
else
{
echo "no results";
}
$con->close();
?>

       </div>
      </div>
      <br>
      <br>
      <br>

 <div class="recruitrounded">
     <div class="TopRounded">
     <div class="sastexthead">
     Receptionists & Secretaries
        </div>
     </div>
    <br>
    <br>
    <div class="container2">
    <?php
    //Linking the configuration file
    require 'config.php';
    $sql = "select * from jobseekerrecep";
    $result = $con->query($sql);
    if($result->num_rows > 0){
    //read data
    while($row = $result->fetch_assoc()){
    //Read and utilize the row data
    echo '<div class="box3">';
    echo ' <img src="data:image/jfif;base64,'.base64_encode($row['JSR_image'] ).'" class="img-thumbnail" />';
    echo '<div class="rsastext">';
    echo " <BR/> " ."My Name:"." <BR/> ". $row["JSR_name"] . "<BR />". "<BR />".'My ID:' . $row["JSR_ID"] . "<BR />". "<BR />"
    ."Contact me:". "<BR />". $row["JSR_contact"]. "<BR />" . $row["JSR_email"] . "<BR/>" ;
    echo '</div>';
    echo '</div>';
    }
    }
    else
    {
    echo "no results";
    }
    $con->close();
    ?>

        </div>
        </div>
        <br>
        <br>
        <br>
        <div class="recruitrounded">
            <div class="TopRounded">
            <div class="sastexthead">
            Accountants
            </div>
            </div>
            <br>
            <br>
        <div class="container2">
            <?php
    //Linking the configuration file
    require 'config.php';
    $sql = "select * from jobseekeracct";
    $result = $con->query($sql);
    if($result->num_rows > 0){
    //read data
    while($row = $result->fetch_assoc()){
    //Read and utilize the row data
    echo '<div class="box3">';
    echo ' <img src="data:image/jfif;base64,'.base64_encode($row['JSA_image'] ).'" class="img-thumbnail" />';
    echo '<div class="rsastext">';
    echo " <BR/> " ."My Name:"." <BR/> ". $row["JSA_name"] . "<BR />". "<BR />".'My ID:' . $row["JSA_ID"] . "<BR />". "<BR />"
    ."Contact me:". "<BR />". $row["JSA_contact"]. "<BR />" . $row["JSA_email"] . "<BR/>" ;
    echo '</div>';
    echo '</div>';
    }
    }
    else
    {
    echo "no results";
    }
    $con->close();
    ?>

        </div>
        </div>

        <br>
        <br>
</center>
</div>
</body>
</html>